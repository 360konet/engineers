<?php

namespace App\Listeners;

use App\Events\DonationSubmitted;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Queue\InteractsWithQueue;
use App\Notifications\DonationSubmittedNotification;

class SendDonationSMS
{
    /**
     * Create the event listener.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    /**
     * Handle the event.
     *
     * @param  \App\Events\DonationSubmitted  $event
     * @return void
     */
    public function handle(DonationSubmitted $event)
    {
        $donationData = $event->donationData;
    
        // Implement your SMS sending logic here
        $donationData->notify(new DonationSubmittedNotification($donationData));
    }

}
