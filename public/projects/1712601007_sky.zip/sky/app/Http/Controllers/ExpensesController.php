<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Expenses;

class ExpensesController extends Controller
{
    //

    public function add_expenses(Request $request){
        $expenses = new Expenses();

        $expenses -> expense_item = $request->input('expense_item');
        $expenses -> expense_amount = $request->input('expense_amount');

        $expenses->save();
        return redirect('/');
    }
}
