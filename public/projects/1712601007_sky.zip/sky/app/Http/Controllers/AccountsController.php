<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Expenses;
use App\Models\Donation;


class AccountsController extends Controller
{
    //
    public function accounts(){
        $donations = Donation::all();

        //General Donation
        $gencedis = Donation::where('account','General Donation')->where('currency','GHC')->sum('donation_amount');
        $gendollars = Donation::where('account','General Donation')->where('currency','$')->sum('donation_amount');
        $genpounds = Donation::where('account','General Donation')->where('currency','GBP')->sum('donation_amount');

        //Wife Donation
        $wifecedis = Donation::where('account','Wife')->where('currency','GHC')->sum('donation_amount');
        $wifedollars = Donation::where('account','Wife')->where('currency','$')->sum('donation_amount');
        $wifepounds = Donation::where('account','Wife')->where('currency','GBP')->sum('donation_amount');

        //Children Donation
        $childcedis = Donation::where('account','Children')->where('currency','GHC')->sum('donation_amount');
        $childdollars = Donation::where('account','Children')->where('currency','$')->sum('donation_amount');
        $childpounds = Donation::where('account','Children')->where('currency','GBP')->sum('donation_amount');

        //Total
        $expcedis =  Expenses::select('expense_item')->sum('expense_amount');
        $totaldonation = $gencedis + $wifecedis + $childcedis;
        $balance = $totaldonation -  $expcedis;

        $expenses = Expenses::all();
        return view ('accounts',compact('donations','expenses','gencedis','gendollars','genpounds','wifecedis','wifedollars','wifepounds','childcedis','childdollars','childpounds','expcedis','totaldonation','balance'));
    }
}
