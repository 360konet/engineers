<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Donation;
use App\Events\DonationSubmitted;


class DonationController extends Controller
{
    //
    public function add_donation(Request $request){
        $donations = new Donation();

        $donations->donor_name=$request->input('donor_name');
        $donations->donor_contact=$request->input('donor_contact');
        $donations->currency=$request->input('currency');
        $donations->payment_method=$request->input('payment_method');
        $donations->account=$request->input('account');
        $donations->relation=$request->input('relation');
        $donations->donation_amount=$request->input('donation_amount');
        $donations->other_donation=$request->input('other_donation');

        $donations->save();
        // Dispatch the event
        event(new DonationSubmitted($donations));
        
        return redirect('/');
    }



}
