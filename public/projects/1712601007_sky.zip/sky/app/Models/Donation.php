<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Notifications\Notifiable; 

class Donation extends Model
{
    use HasFactory, Notifiable;
    
    protected $table='donations';

    protected $fillable = [
        'donor_name',
        'donor_contact',
        'currency',
        'payment_method',
        'account',
        'relation',
        'donation_amount',
        'other_donation'
    ];


   
}
