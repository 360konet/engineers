<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link href="https://fonts.googleapis.com/css?family=Poppins:400,500,600,700&display=swap" rel="stylesheet">
  <style>
    body {
      display: flex;
      align-items: center;
      justify-content: center;
      min-height: 100vh;
      padding: 10px;
      font-family: 'Poppins', sans-serif;
      background: linear-gradient(115deg, #56d8e4 10%, #9f01ea 90%);
    }

    .container {
      max-width: 100%;
      background: #fff;
      width: 90%;
      padding: 20px;
      box-shadow: 0px 0px 10px rgba(0,0,0,0.1);
      margin-top: -100px;
    }

    .container .text {
      text-align: center;
      font-size: 30px;
      font-weight: 600;
      background: -webkit-linear-gradient(right, #56d8e4, #9f01ea, #56d8e4, #9f01ea);
      -webkit-background-clip: text;
      -webkit-text-fill-color: transparent;
    }

    .container button {
      margin-top: 10px;
    }

    .container form {
      padding: 15px 0 0 0;
    }

    .container form .form-row {
      display: flex;
      flex-wrap: wrap;
      margin: 32px 0;
    }

    form .form-row .input-data select {
      width: 100%;
      height: 40px;
      margin: 10px 0;
      position: relative;
      appearance: none;
      -webkit-appearance: none;
      -moz-appearance: none;
    }

    form .form-row .textarea {
      height: 70px;
    }

    .input-data input,
    .textarea textarea {
      display: block;
      width: 100%;
      height: 100%;
      border: none;
      font-size: 17px;
      border-bottom: 2px solid rgba(0,0,0, 0.12);
    }

    .input-data input:focus ~ label,
    .textarea textarea:focus ~ label,
    .input-data input:valid ~ label,
    .textarea textarea:valid ~ label {
      transform: translateY(-20px);
      font-size: 14px;
      color: #3498db;
    }

    .textarea textarea {
      resize: none;
      padding-top: 10px;
    }

    .input-data label {
      position: absolute;
      pointer-events: none;
      bottom: 10px;
      font-size: 16px;
      transition: all 0.3s ease;
    }

    .textarea label {
      width: 100%;
      bottom: 40px;
      background: #fff;
    }

    .input-data .underline {
      position: absolute;
      bottom: 0;
      height: 2px;
      width: 100%;
    }

    .input-data .underline:before {
      position: absolute;
      content: "";
      height: 2px;
      width: 100%;
      background: #3498db;
      transform: scaleX(0);
      transform-origin: center;
      transition: transform 0.3s ease;
    }

    .input-data input:focus ~ .underline:before,
    .input-data input:valid ~ .underline:before,
    .textarea textarea:focus ~ .underline:before,
    .textarea textarea:valid ~ .underline:before {
      transform: scale(1);
    }

    .submit-btn .input-data {
      overflow: hidden;
      height: 45px!important;
      width: 100%!important;
    }

    .submit-btn .input-data .inner {
      height: 100%;
      width: 300%;
      position: absolute;
      left: -100%;
      background: -webkit-linear-gradient(right, #56d8e4, #9f01ea, #56d8e4, #9f01ea);
      transition: all 0.4s;
    }

    .submit-btn .input-data:hover .inner {
      left: 0;
    }

    .submit-btn .input-data input {
      background: none;
      border: none;
      color: #fff;
      font-size: 17px;
      font-weight: 500;
      text-transform: uppercase;
      letter-spacing: 1px;
      cursor: pointer;
      position: relative;
      z-index: 2;
    }

    @media (max-width: 700px) {
      .container .text {
        font-size: 30px;
      }
      .container form {
        padding: 10px 0 0 0;
      }
      .container form .form-row {
        display: block;
        margin: 20px 0;
      }
      .form-row .input-data {
        width: 100%;
        margin: 10px 0;
      }
      .submit-btn .input-data {
        width: 100%;
      }
      .expenses-container .form-row .textarea {
        height: auto;
      }
    }
  </style>
</head>
<body>
  <div class="container">
    <div class="text" id="donationText">
      Donations Form <button style="float:right" onclick="toggleForms('expenses')">Expenses</button>
    </div>
    <form id="donationForm" method="POST" onsubmit="prepareSMSLink()" action="<?php echo e(url('/add-donation')); ?>">
      <?php echo csrf_field(); ?>
      <a href="<?php echo e(url('/view_accounts')); ?>" style="float:right;">View Accounts</a>
      <div class="form-row">
        <div class="input-data">
          <input type="text" name="donor_name" placeholder="Enter Donor's Name">
          <div class="underline"></div>
        </div>
        <div class="input-data">
          <input type="text" name="donor_contact" id="donor_contact" placeholder="Enter Donor's Contact">
          <div class="underline"></div>
        </div>
      </div>
      <div class="form-row">
        <div class="input-data">
          <select name="currency">
            <option value="GHC" selected>GHC</option>
            <option value="">--Change Currency--</option>
            <option value="$">US Dollars</option>
            <option value="GBP">Pounds</option>
          </select>
          <select name="payment_method">
            <option value="Cash" selected>Cash</option>
            <option value="">--Change Method--</option>
            <option value="Mobile Money">Mobile Money</option>
            <option value="Bank">Bank</option>
          </select>
          <select name="account">
            <option value="General Donation" selected>General Donation</option>
            <option value="">-- Change Account--</option>
            <option value="Wife">Wife</option>
            <option value="Children">Children</option>
          </select>
          <select name="relation">
            <option value="Family Member" selected>Family Member</option>
            <option value="">-- Change Relation--</option>
            <option value="Family Friend">Family Friend</option>
            <option value="Friend">Friend</option>
            <option value="Others">Others</option>
          </select>
        </div>
        <br><br>
        <div class="input-data">
          <input type="number" name="donation_amount" placeholder="Enter Amount">
          <div class="underline"></div>
        </div>
      </div>
      <div class="form-row">
        <div class="input-data textarea">
          <textarea rows="8" cols="80" name="other_donation" placeholder="Enter Other Donations"></textarea>
          <br />
          <div class="underline"></div>
          <div class="form-row submit-btn">
            <div class="input-data">
              <div class="inner"></div>
              <input type="submit" value="submit">
            </div>
          </div>            
        </div>
      </form>
    </div>

    <div class="text" id="expensesText" style="display: none;">
      Expenses Form <button style="float:right;" onclick="toggleForms('donation')">Donate</button>
    </div>
    <form method="Post" action="<?php echo e(url('/add_expense')); ?>" id="expensesForm" style="display: none;">
      <?php echo csrf_field(); ?>
      <div class="form-row">
        <div class="input-data">
          <input type="text" name="expense_item" placeholder="Enter Expense Item">
          <div class="underline"></div>
          <label for="">Expense Item</label>
        </div>
        <div class="input-data">
          <input type="number" name="expense_amount" placeholder="Enter Expense Amount">
          <div class="underline"></div>
          <label for="">Amount (GHC)</label>
        </div>
      </div>
      <div class="form-row">
      </div>
      <div class="form-row submit-btn">
        <div class="input-data">
          <div class="inner"></div>
          <input type="submit" value="submit">
        </div>
      </div>
    </form>
  </div>

  <script>
    function toggleForms(showForm) {
      const donationContainer = document.getElementById('donationText');
      const expensesContainer = document.getElementById('expensesText');
      const donationForm = document.getElementById('donationForm');
      const expensesForm = document.getElementById('expensesForm');
      
      if (showForm === 'expenses') {
        donationContainer.style.display = 'none';
        expensesContainer.style.display = 'block';
        donationForm.style.display = 'none';
        expensesForm.style.display = 'block';
      } else {
        donationContainer.style.display = 'block';
        expensesContainer.style.display = 'none';
        donationForm.style.display = 'block';
        expensesForm.style.display = 'none';
      }
    }

    // Call toggleForms to set the initial state (show donation form)
    toggleForms('donation');
  </script>

<script>
    function prepareSMSLink() {
        const donorContact = document.getElementById('donor_contact').value;
        const donorName = document.getElementsByName('donor_name')[0].value;
        const donationAmount = document.getElementsByName('donation_amount')[0].value;
        const donationCurrency = document.getElementsByName('currency')[0].value;
        const otherDonation = document.getElementsByName('other_donation')[0].value;

        // Check if a donor contact number is provided
        if (donorContact.trim() !== '') {
            const smsMessage = `Dear ${donorName}, thank you for supporting us with  ${donationCurrency} ${donationAmount}. ${otherDonation}. Appriciation from the YEBOAH Family`;
            const encodedMessage = encodeURIComponent(smsMessage);
            const smsLink = `sms:${donorContact}?body=${encodedMessage}`;

            // Open the SMS app with the pre-filled message
            window.location.href = smsLink;
        } else {
            // No donor contact number provided, submit the form without sending an SMS
            document.getElementById('donationForm').submit();
        }
    }
</script>

</body>
</html>
<?php /**PATH C:\xampp\htdocs\sky\resources\views/welcome.blade.php ENDPATH**/ ?>