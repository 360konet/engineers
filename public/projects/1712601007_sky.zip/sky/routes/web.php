<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\DonationController;
use App\Http\Controllers\ExpensesController;
use App\Http\Controllers\AccountsController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Route::post('/add-donation',[DonationController::class,'add_donation']);


Route::post('/add_expense',[ExpensesController::class,'add_expenses']);

Route::get('view_accounts',[AccountsController::class,'accounts']);

Route::get('/test',[DonationController::class,'testTwilioSMS']);
