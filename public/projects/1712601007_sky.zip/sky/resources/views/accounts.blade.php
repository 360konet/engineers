<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.datatables.net/2.0.0/css/dataTables.dataTables.css" />
    <script src="https://cdn.datatables.net/2.0.0/js/dataTables.js"></script>
    <title>SKY</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
        }

        .cards-container {
            display: flex;
            flex-wrap: wrap; /* Allow cards to wrap to the next line on smaller screens */
            justify-content: space-around;
            margin: 20px;
        }

        .card {
            width: calc(33.33% - 20px); /* Adjust the width based on your needs */
            margin: 10px;
            padding: 20px;
            border-radius: 8px;
            box-sizing: border-box;
            color: #fff;
            text-align: center;
        }

        .card1 {
            background: linear-gradient(to right, #ff6b6b, #ffa07a);
        }

        .card2 {
            background: linear-gradient(to right, #6a11cb, #2575fc);
        }

        .card3 {
            background: linear-gradient(to right, #74ebd5, #acb6e5);
        }

        .datatable-card {
            background-color: #36454F;
            width: 100%; /* Full width for mobile */
            padding: 20px;
            border-radius: 8px;
            box-sizing: border-box;
            margin: 20px auto;
            color: #fff;
            text-align: center;
            overflow-x: auto;
        }

        
        #myDataTable {
            width: 100%; /* Full width for mobile */
        }

        /* Additional styles to make DataTable responsive */
        @media (max-width: 768px) {
            .cards-container {
                justify-content: center;
            }
            .card {
                width: 100%;
            }
        }

        .heading{
  text-align: center;
  font-size: 30px;
  font-weight: 600;
  font-family: 'Poppins', sans-serif;
  background: -webkit-linear-gradient(right, #56d8e4, #9f01ea, #56d8e4, #9f01ea);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
}


    </style>
</head>
<body>

<a href="{{url('/')}}" class="hide-in-pdf"><button style="height:40px; width:100px;background-color:red; border-radius: 8px;"><b>X Close</b></button></a> 
<button onclick="generatePDF()" class="hide-in-pdf" style="height:40px; width:100px;background: linear-gradient(to right, #ff6b6b, #ffa07a); border-radius: 8px; float:right;">
    <b>Print</b>
</button>


<div class="heading" id="donationText">
    Account Summary
  </div>

  <div class="cards-container">
    <div class="card card1">
        <h3>Total Donation = GHC {{$totaldonation}}</h2>
        <h3>Total Expenses = GHC {{$expcedis}}</h2>
        <h2>Balance = GHC {{$balance}}</h2>
</div>
</div>


  <!-- <div class="heading" id="donationText">
    Donation Summary
  </div>
<div class="cards-container">
    <div class="card card1">
        <h2>General</h2>
        <p>Cedis : GHC {{$gencedis}}</p>
        <p>Dollars : $ {{$gendollars}} </p>
        <p>Pounds : GBP {{$genpounds}}</p>
    </div>

    <div class="card card2">
        <h2>Wife</h2>
        <p>Cedis : GHC {{$wifecedis}}</p>
        <p>Dollars : $ {{$wifedollars}} </p>
        <p>Pounds : GBP {{$wifepounds}}</p>
    </div>

    <div class="card card3">
        <h2>Children</h2>
        <p>Cedis : GHC {{$childcedis}}</p>
        <p>Dollars : $ {{$childdollars}} </p>
        <p>Pounds : GBP {{$childpounds}}</p>
    </div>
</div> -->

<div class="datatable-card">
    <table id="myDataTable" class="display">
    <div class="heading" id="donationText">
      Donations  Breakdown
    </div>
    <br><br>
        <thead>
            <tr>
                <th>Donor's Name</th>
                <th>Donor's Contact</th>
                <th>Donations</th>
                <th>Amount</th>
                <th>Payment Method</th>
                <th>Account</th>
                <th>Donated On</th>
            </tr>
        </thead>
        <tbody>
            @foreach($donations as $donation)
            <tr>
                <td>{{$donation->donor_name}}</td>
                <td>{{$donation->donor_contact}}</td>
                <td>{{$donation->other_donation}}</td>
                <td>{{$donation->currency}} {{$donation->donation_amount}}</td>
                <td>{{$donation->payment_method}}</td>
                <td>{{$donation->account}}</td>
                <td>{{$donation->created_at}}</td>
            </tr>
            @endforeach
            <!-- Add more rows as needed -->
        </tbody>
    </table>
</div>


<div class="datatable-card">
    <table id="myDataTable2" class="display">
    <div class="heading" id="donationText">
      Expenses Breakdown
    </div>
    <br><br>
        <thead>
            <tr>
                <th>Expense Item</th>
                <th>Amount</th>
                <th>Date/Time</th>
            </tr>
        </thead>
        <tbody>
            @foreach($expenses as $expense)
            <tr>
                <td>{{$expense->expense_item}}</td>
                <td>{{$expense->expense_amount}}</td>
                <td>{{$expense->created_at}}</td>
            </tr>
            @endforeach
            <!-- Add more rows as needed -->
        </tbody>
    </table>
</div>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/2.0.0/js/dataTables.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.4.0/jspdf.umd.min.js"></script>

<script src="https://rawgit.com/eKoopmans/html2pdf/master/dist/html2pdf.bundle.js"></script>


<script>
    $(document).ready( function () {
        $('#myDataTable').DataTable();
    } );
</script>

<script>
    $(document).ready( function () {
        $('#myDataTable2').DataTable();
    } );
</script>



<script>
    function generatePDF() {
    // Save the original buttons
    var originalButtons = {
        closeButton: document.querySelector('.hide-in-pdf button'),
        printButton: document.querySelector('.hide-in-pdf-print button')
    };

    // Check if buttons exist before attempting to hide them
    if (originalButtons.closeButton) {
        originalButtons.closeButton.style.display = 'none';
    }

    if (originalButtons.printButton) {
        originalButtons.printButton.style.display = 'none';
    }

    // Create buttons for PDF
    var closeButtonPDF = document.createElement('button');
    closeButtonPDF.style.height = '40px';
    closeButtonPDF.style.width = '100px';
    closeButtonPDF.style.backgroundColor = 'red';
    closeButtonPDF.style.borderRadius = '8px';
    closeButtonPDF.textContent = 'X Close';

    var printButtonPDF = document.createElement('button');
    printButtonPDF.style.height = '40px';
    printButtonPDF.style.width = '100px';
    printButtonPDF.style.background = 'linear-gradient(to right, #ff6b6b, #ffa07a)';
    printButtonPDF.style.borderRadius = '8px';
    printButtonPDF.style.float = 'right';
    printButtonPDF.textContent = 'Print';

    // Append buttons to the PDF content
    document.body.appendChild(closeButtonPDF);
    document.body.appendChild(printButtonPDF);

    // Generate PDF
    html2pdf(document.body, {
        margin: 10,
        filename: 'account.pdf',
        image: { type: 'jpeg', quality: 0.98 },
        html2canvas: { scale: 2 },
        jsPDF: { unit: 'mm', format: 'a4', orientation: 'portrait' }
    });

    // Remove buttons created for PDF
    closeButtonPDF.remove();
    printButtonPDF.remove();

    // Restore original buttons
    if (originalButtons.closeButton) {
        originalButtons.closeButton.style.display = '';
    }

    if (originalButtons.printButton) {
        originalButtons.printButton.style.display = '';
    }
}

</script>




</body>
</html>
